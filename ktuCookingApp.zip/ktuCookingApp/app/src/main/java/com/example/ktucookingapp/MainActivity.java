package com.example.ktucookingapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private Button btnCookingApp, btnLabWork;
    private TextView tfStartMessage;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnCookingApp = (Button) findViewById(R.id.btnCookingApp);
        btnLabWork = (Button) findViewById(R.id.btnLabWork);
        tfStartMessage = (TextView) findViewById(R.id.tfStartMessage);

        btnCookingApp.setOnClickListener(btnCookingAppClick);
        btnLabWork.setOnClickListener(btnLabWorkClick);

    }

    private View.OnClickListener btnCookingAppClick = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent intent = new Intent(MainActivity.this, CookingApp.class);
            startActivity(intent);
        }
    };

    private View.OnClickListener btnLabWorkClick = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
                    Intent intent = new Intent(MainActivity.this, LabWorkOverview.class);
                    startActivity(intent);
        }
    };
}
